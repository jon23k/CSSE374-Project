package problem;

import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class KeyController implements KeyListener {
	private HashMap<Character, ICommand> key;
	private ICommand command;
	
	private ArrayList<Shape> listOfShapes;
//	private ICom command;

	public KeyController(HashMap<Character, ICommand> map, ArrayList<Shape> listOfShapes) {
		this.key = map;
		this.listOfShapes =listOfShapes;
		
	}

	@Override
	public void keyTyped(KeyEvent e){
			try{
			this.command = this.key.get(e.getKeyChar());
			this.command.command(this.listOfShapes);
			}catch(NullPointerException | IOException | ClassNotFoundException exp){
				System.out.println("Invalid Keystroke Or IO Execption");			
		}
			e.getComponent().repaint();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

}

package problem;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class MyPanel extends JPanel {
	private int width;
	private int height;
	private ArrayList<Shape> listOfShapes;
	
	public MyPanel( ArrayList<Shape> listOfShapes) {
	        setBorder(BorderFactory.createLineBorder(Color.black));
	        this.height = 300;
	        this.width = 300;
	        this.listOfShapes = listOfShapes;
	    }

	    public Dimension getPreferredSize() {
	        return new Dimension(this.width,this.height);
	    }

	    public void paintComponent(Graphics g) {
	        super.paintComponent(g); 
	        Graphics2D g2 = (Graphics2D) g;
	        for(int i = 0;i<this.listOfShapes.size();i++){
	        	g2.draw(this.listOfShapes.get(i));
	        }
	        	        
	    }  
}

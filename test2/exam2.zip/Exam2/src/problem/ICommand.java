package problem;

import java.awt.Shape;
import java.io.IOException;
import java.util.ArrayList;

public interface ICommand {
	public void command(ArrayList<Shape> listOfShape) throws IOException, ClassNotFoundException;
	

}

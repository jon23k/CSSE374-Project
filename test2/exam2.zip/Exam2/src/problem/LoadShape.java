package problem;

import java.awt.Shape;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class LoadShape implements ICommand {

//	@SuppressWarnings("unchecked")
	@Override
	public void command(ArrayList<Shape> listOfShape) throws IOException, ClassNotFoundException {
		System.out.println("Loading....");	
			FileInputStream inputFile = new FileInputStream("input_output/savedShapes.txt");
	        ObjectInputStream input = new ObjectInputStream(inputFile);
	        @SuppressWarnings("unchecked")
			ArrayList<Shape> newShapesList = (ArrayList<Shape>) input.readObject();
	        input.close();
	        inputFile.close();
	        listOfShape.clear();
	        for (Shape shape: newShapesList){
	        	listOfShape.add(shape);
	        }	    
	}

	


}

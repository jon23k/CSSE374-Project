package problem;

import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Random;


public class DrawRectangle implements ICommand{
	private int width;
	private int height;
	private int randx;
	private int randy;
	private Random rand;
	private int randValue = 200;
	
	
	public DrawRectangle(){
		this.width = 50;
		this.height = 75;
		this.rand = new Random();
		
		
		
	}
	@Override
	public void command(ArrayList<Shape> shape) {
		this.randx = this.rand.nextInt(randValue);
		this.randy = this.rand.nextInt(randValue);
		Rectangle2D rect = new Rectangle2D.Double(randx,randy,this.width,this.height);
		shape.add(rect);
		
		
		
	}
	

}

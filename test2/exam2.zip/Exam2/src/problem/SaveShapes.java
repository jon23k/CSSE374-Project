package problem;

import java.awt.Shape;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class SaveShapes implements ICommand{
	@Override
	public void command(ArrayList<Shape> listOfShapes) throws IOException{
		System.out.println("Saving...");
			FileOutputStream outputFile = new FileOutputStream("input_output/savedShapes.txt");
			ObjectOutputStream output = new ObjectOutputStream(outputFile);
			output.writeObject(listOfShapes);
			output.close();
			outputFile.close();
			
	}

}

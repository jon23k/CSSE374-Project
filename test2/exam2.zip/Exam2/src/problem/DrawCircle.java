package problem;

import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.Random;

public class DrawCircle implements ICommand {

	private int size;
	private int randx;
	private int randy;
	private Random rand;
	private int randValue = 200;

	public DrawCircle() {
		this.size = 60;
		this.rand = new Random();
		

	}

	@Override
	public void command(ArrayList<Shape> shape) {
		this.randx = this.rand.nextInt(randValue );
		this.randy = this.rand.nextInt(randValue);
		Ellipse2D circle = new Ellipse2D.Double(randx, randy, this.size,this.size);
		shape.add(circle);
	}
}

package problem;

import java.awt.Shape;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class SwingPaintShapes {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				HashMap<Character, ICommand> key = new HashMap<Character, ICommand>();
				ArrayList<Shape> listOfShapes = new ArrayList<Shape>();
				key.put('r', new DrawRectangle());
				key.put('c', new DrawCircle());
				key.put('s', new SaveShapes());
				key.put('u', new UndoShape());
				key.put('t', new LoadShape());
				createAndShowGUI(key,listOfShapes);
			}
		});
	}

	private static void createAndShowGUI(HashMap<Character, ICommand> map, ArrayList<Shape> listOfShapes) {
		System.out.println("Created GUI on EDT? "
				+ SwingUtilities.isEventDispatchThread());
		JFrame f = new JFrame("Shapes");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MyPanel panel = new MyPanel(listOfShapes);
		KeyController controller = new KeyController(map,listOfShapes);
		panel.addKeyListener(controller);
		f.add(panel);
		f.pack();
		f.setVisible(true);
		panel.grabFocus();
	}

}

package problem;

import java.awt.Shape;
import java.util.ArrayList;

public class UndoShape implements ICommand {

	@Override
	public void command(ArrayList<Shape> listOfShape) {
		if (listOfShape.size() > 0)
			listOfShape.remove(listOfShape.size() - 1);

	}

}

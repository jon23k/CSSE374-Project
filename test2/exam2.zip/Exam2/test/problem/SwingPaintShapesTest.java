package problem;
import static org.junit.Assert.*;

import java.awt.Shape;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SwingPaintShapesTest {
	private ArrayList<Shape> listOfShapes;
	private DrawRectangle rect;
	private DrawCircle circle;
	private UndoShape undo;
	private SaveShapes save;
	private LoadShape load;
	
	@Before
	public void setUp() throws Exception {
		listOfShapes = new ArrayList<Shape>(); 
		this.rect = new DrawRectangle();
		this.circle = new DrawCircle();
		this.undo = new UndoShape();
		this.save = new SaveShapes();
		this.load = new LoadShape();
	}

	@After
	public void tearDown() throws Exception {
		listOfShapes = new ArrayList<Shape>();
	}
	
	@Test
	public void addingShapes(){
		assertEquals(this.listOfShapes.size(), 0);
		this.rect.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 1);
		this.circle.command(listOfShapes);
		this.rect.command(listOfShapes);
		this.circle.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 4);
		
	}
	@Test
	public void undoShapes(){
		assertEquals(this.listOfShapes.size(), 0);
		this.rect.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 1);
		this.circle.command(listOfShapes);
		this.rect.command(listOfShapes);
		this.circle.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 4);
		this.undo.command(this.listOfShapes);
		assertEquals(this.listOfShapes.size(), 3);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		assertEquals(this.listOfShapes.size(), 0);
			
	}

	@Test
	public void SaveandLoadShapes() throws IOException, ClassNotFoundException{
		assertEquals(this.listOfShapes.size(), 0);
		this.rect.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 1);
		this.circle.command(listOfShapes);
		this.rect.command(listOfShapes);
		this.circle.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 4);
		this.save.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		assertEquals(this.listOfShapes.size(), 0);
		this.load.command(this.listOfShapes);
		assertEquals(this.listOfShapes.size(), 4);			
	}
	@Test
	public void LoadFromstartupShapes() throws IOException, ClassNotFoundException{
		assertEquals(this.listOfShapes.size(), 0);
		assertEquals(this.listOfShapes.size(), 0);
		this.rect.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 1);
		this.circle.command(listOfShapes);
		this.rect.command(listOfShapes);
		this.circle.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 4);
		this.save.command(this.listOfShapes);
		this.load.command(this.listOfShapes);
		assertEquals(this.listOfShapes.size(), 4);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		assertEquals(this.listOfShapes.size(), 0);		
		
	}
	@Test 
	public void addingAndLoading() throws IOException, ClassNotFoundException{
		assertEquals(this.listOfShapes.size(), 0);
		this.rect.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 1);
		this.circle.command(listOfShapes);
		this.rect.command(listOfShapes);
		this.circle.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 4);
		this.save.command(this.listOfShapes);
		this.load.command(this.listOfShapes);
		assertEquals(this.listOfShapes.size(), 4);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		this.undo.command(this.listOfShapes);
		assertEquals(this.listOfShapes.size(), 0);
		this.rect.command(this.listOfShapes);
		this.circle.command(this.listOfShapes);
		assertEquals(this.listOfShapes.size(), 2);
		this.load.command(listOfShapes);
		assertEquals(this.listOfShapes.size(), 4);
	}
	

}

package problem;

import java.util.List;

public interface IApplication {
	
	public String toString(String command, List<String> args);
		

}

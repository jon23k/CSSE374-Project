package problem;

public class CmdFrameworkApp {

	public static void main(String[] args) throws Exception {
		CmdFramework cmdFramework = new CmdFramework();
		cmdFramework.execute();
	}
}

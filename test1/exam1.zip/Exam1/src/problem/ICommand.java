package problem;

import java.util.List;

public interface ICommand {
	
	public String commandExecute(List<String> args);

}

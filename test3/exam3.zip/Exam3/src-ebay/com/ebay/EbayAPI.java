package com.ebay;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EbayAPI {
	EBayCatalog catalog;
	
	public EbayAPI() {
		catalog = new EBayCatalog("Best Seller");
		DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);
		
		// Assume RESTful calls to get these records

		// Book 1
		String string = "October 1, 2004";
		Date date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {}
		EBayBook b = new EBayBook("Head First Design Patterns", 
				"978-0-596-00712-6",
				new String[]{"Eric Freeman", "Elisabeth Freeman"},
				"O'Reilly",
				date, 
				30.50f);
		catalog.add(b);
		

		// Book 2
		string = "October 1, 2005";
		date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {}
		b = new EBayBook("Head First C++", 
				"978-0-596-00712-7",
				new String[]{"Eric Fordeman", "Elisabeth Haggerman"},
				"Addison Wesley",
				date, 
				110f);
		catalog.add(b);

		// Book 3
		string = "September 12, 1982";
		date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {}
		b = new EBayBook("Love and Peace", 
				"978-0-596-00712-8",
				new String[]{"Bob Marley", "Pink Floyd"},
				"Music Inc.",
				date, 
				32f);
		catalog.add(b);

		// Book 4
		string = "November 18, 1801";
		date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {}
		b = new EBayBook("Love and Prayer", 
				"978-0-596-00712-8",
				new String[]{"Bob Marr", "Pink Panther"},
				"Church Inc.",
				date, 
				10.35f);
		catalog.add(b);
		// Book 5
		string = "September 15, 1989";
		date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {}
		b = new EBayBook("The Design Patterns in Software Systems", 
				"978-0-596-00713-8",
				new String[]{"Chandan R. Rupakheti"},
				"Rose-Hulman",
				date, 
				30f);
		catalog.add(b);
	}
	
	public EBayBook[] getBooks() {
		return catalog.getBooks();
	}
	
	public EBayBook[] getBooksSortedByPrice() {
		return catalog.sortByPrice();
	}
	
	public EBayBook[] getBooksSortedByRelevance(String searchTerm) {
		return catalog.sortByRelevance(searchTerm);
	}
}

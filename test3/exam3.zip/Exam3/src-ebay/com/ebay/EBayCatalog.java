package com.ebay;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class EBayCatalog {
	String name;
	Set<EBayBook> eBayBooks;
	
	public EBayCatalog(String name) {
		this.name = name;
		eBayBooks = new HashSet<EBayBook>();
	}
	
	public void add(EBayBook b) {
		this.eBayBooks.add(b);
	}
	
	public EBayBook[] getBooks() {
		return eBayBooks.toArray(new EBayBook[0]);
	}
	
	public EBayBook[] sortByPrice() {
		Set<EBayBook> sortedBooks = new TreeSet<EBayBook>(new Comparator<EBayBook>() {

			@Override
			public int compare(EBayBook o1, EBayBook o2) {
				if(o1.equals(o2))
					return 0;
				
				if(o1.getPrice() < o2.getPrice())
					return -1;
				
				return 1;
			}
			
		});
		sortedBooks.addAll(eBayBooks);
		return sortedBooks.toArray(new EBayBook[0]);
	}

	public EBayBook[] sortByRelevance(final String searchTerm) {
		Set<EBayBook> sortedBooks = new TreeSet<EBayBook>(new Comparator<EBayBook>() {

			@Override
			public int compare(EBayBook o1, EBayBook o2) {
				if(o1.equals(o2))
					return 0;
				
				int o1Dist = getMinDistance(searchTerm, o1.getTitle());
				int o2Dist = getMinDistance(searchTerm, o2.getTitle());

				if(o1Dist < o2Dist)
					return -1;
				
				// Greater or equal
				return 1;
			}
		});
		sortedBooks.addAll(eBayBooks);
		return sortedBooks.toArray(new EBayBook[0]);
	}
	
	
	private int getMinDistance(String source, String dest) {
		DamerauLevenshteinAlgorithm algorithm = new DamerauLevenshteinAlgorithm(1, 1, 2, 3);
		String[] terms = dest.split(" ");
		int min = 1000;
		for(String t: terms) {
			int dist = algorithm.execute(source, t);
			min = (min < dist)?min:dist;
		}
		return min;
	}	
}

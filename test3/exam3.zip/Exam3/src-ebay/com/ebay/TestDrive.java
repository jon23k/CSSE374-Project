package com.ebay;

public class TestDrive {
	public static void main(String[] args) {
		EbayAPI api  = new EbayAPI();
		
		
		EBayBook[] books = api.getBooks();
		print("EBay Books - All", books);
		
		books = api.getBooksSortedByPrice();		
		print("EBay Books - Sorted by Price", books);
		
		String searchTerm = "Love"; // Change me to "Design"
		books = api.getBooksSortedByRelevance(searchTerm);		
		print("EBay Books - Sorted by Relevance [" + searchTerm + "]", books);
	}
	
	public static void print(String title, EBayBook[] books) {
		System.out.println(title);
		System.out.println("-----------------------------------------------");
		for(EBayBook b: books) {
			System.out.println(b);
		}
		System.out.println("-----------------------------------------------\n");
	}
}

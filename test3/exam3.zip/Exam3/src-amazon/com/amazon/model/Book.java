package com.amazon.model;

import java.util.Arrays;
import java.util.Date;

public class Book {
	float cost;
	String title;
	String isbn;
	String[] authors;
	String publisher;
	Date pubDate;
	
	public Book(String title, String isbn, String[] authors, String publisher, Date pubDate, float cost) {
		this.title = title;
		this.isbn = isbn;
		this.authors = authors;
		this.publisher = publisher;
		this.pubDate = pubDate;
		this.cost = cost;
	}

	public float getCost() {
		return cost;
	}

	public String getTitle() {
		return title;
	}

	public String getISBN() {
		return isbn;
	}

	public String[] getAuthors() {
		return authors;
	}

	public String getPublisher() {
		return publisher;
	}

	public Date getPublicationDate() {
		return pubDate;
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(authors);
		result = prime * result + Float.floatToIntBits(cost);
		result = prime * result + ((isbn == null) ? 0 : isbn.hashCode());
		result = prime * result + ((pubDate == null) ? 0 : pubDate.hashCode());
		result = prime * result
				+ ((publisher == null) ? 0 : publisher.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (!Arrays.equals(authors, other.authors))
			return false;
		if (Float.floatToIntBits(cost) != Float.floatToIntBits(other.cost))
			return false;
		if (isbn == null) {
			if (other.isbn != null)
				return false;
		} else if (!isbn.equals(other.isbn))
			return false;
		if (pubDate == null) {
			if (other.pubDate != null)
				return false;
		} else if (!pubDate.equals(other.pubDate))
			return false;
		if (publisher == null) {
			if (other.publisher != null)
				return false;
		} else if (!publisher.equals(other.publisher))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Book [title=" + title + ", isbn=" + isbn
				+ ", authors=" + Arrays.toString(authors) + ", publisher="
				+ publisher + ", pubDate=" + pubDate + 
				", cost=" + cost + "]";
	}

	
}

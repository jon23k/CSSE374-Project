package com.amazon.model;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Catalog {
	String name;
	Set<Book> books;
	
	public Catalog(String name) {
		this.name = name;
		books = new HashSet<Book>();
	}
	
	public void add(Book b) {
		this.books.add(b);
	}
	
	public Set<Book> getBooks() {
		return Collections.unmodifiableSet(books);
	}
	
	public Set<Book> getBooks(Comparator<Book> sorter) {
		Set<Book> sortedBooks = new TreeSet<Book>(sorter);
		sortedBooks.addAll(books);
		return sortedBooks;
	}
}

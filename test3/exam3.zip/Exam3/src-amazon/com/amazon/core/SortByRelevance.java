package com.amazon.core;

import java.util.Comparator;

import com.amazon.model.Book;

public class SortByRelevance implements Comparator<Book> {
	String searchTerm;
	
	public SortByRelevance(String searchTerm) {
		this.searchTerm = searchTerm;
	}
	

	@Override
	public int compare(Book o1, Book o2) {
		if(o1.equals(o2))
			return 0;
		int o1Dist = getMinDistance(searchTerm, o1.getTitle());
		int o2Dist = getMinDistance(searchTerm, o2.getTitle());

		if(o1Dist < o2Dist)
			return -1;
		
		// Greater or equal
		return 1;
	}
	
	private int getMinDistance(String source, String dest) {
		String[] terms = dest.split(" ");
		int min = 1000;
		for(String t: terms) {
			int dist = LevenshteinDistance.compute(source, t);
			min = (min < dist)?min:dist;
		}
		return min;
	}
}

package com.amazon.core;

import java.util.Comparator;

import com.amazon.model.Book;

public class SortByPrice implements Comparator<Book> {
	@Override
	public int compare(Book o1, Book o2) {
		if(o1.equals(o2))
			return 0;
		
		if(o1.getCost() < o2.getCost())
			return -1;
		
		// Greater or equal
		return 1;
	}
}

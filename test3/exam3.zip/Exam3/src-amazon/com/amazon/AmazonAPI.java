package com.amazon;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Set;

import com.amazon.core.SortByPrice;
import com.amazon.core.SortByRelevance;
import com.amazon.model.Book;
import com.amazon.model.Catalog;

public class AmazonAPI {
	Catalog catalog;
	
	public AmazonAPI() {
		catalog = new Catalog("Best Seller");
		DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);
		
		// NOTE: Assume making RESTful call to Amazon web services to retrieve the following info

		// Book 1
		String string = "October 1, 2004";
		Date date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {}
		Book b = new Book("Head First Design Patterns", 
				"978-0-596-00712-6",
				new String[]{"Eric Freeman", "Elisabeth Freeman"},
				"O'Reilly",
				date, 
				49.98f);
		catalog.add(b);
		

		// Book 2
		string = "October 1, 2005";
		date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {}
		b = new Book("Head First C++", 
				"978-0-596-00712-7",
				new String[]{"Eric Fordeman", "Elisabeth Haggerman"},
				"Addison Wesley",
				date, 
				100f);
		catalog.add(b);

		// Book 3
		string = "September 12, 1982";
		date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {}
		b = new Book("Love and Peace", 
				"978-0-596-00712-8",
				new String[]{"Bob Marley", "Pink Floyd"},
				"Music Inc.",
				date, 
				32f);
		catalog.add(b);

		// Book 4
		string = "November 18, 1801";
		date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {}
		b = new Book("Love and Prayer", 
				"978-0-596-00712-8",
				new String[]{"Bob Marr", "Pink Panther"},
				"Church Inc.",
				date, 
				10.35f);
		catalog.add(b);
	}
	
	public Set<Book> getBooks() {
		return catalog.getBooks();
	}
	
	public Set<Book> getBooksSortedByPrice() {
		return catalog.getBooks(new SortByPrice());
	}
	
	public Set<Book> getBooksSortedByRelevance(String searchTerm) {
		return catalog.getBooks(new SortByRelevance(searchTerm));
	}
}

package problem;

import java.util.Set;

import com.amazon.AmazonAPI;
import com.amazon.model.Book;

public class Client {
	public static void main(String[] args) {
		AmazonAPI api  = new AmazonAPI();
		
		
		Set<Book> books = api.getBooks();
		print("Amazon Books - All", books);
		
		books = api.getBooksSortedByPrice();		
		print("Amazon Books - Sorted by Price", books);
		
		String searchTerm = "Love"; // Change me to "Design"
		books = api.getBooksSortedByRelevance(searchTerm);		
		print("Amazon Book - Sorted by Relevance [" + searchTerm + "]", books);
	}
	
	public static void print(String title, Set<Book> books) {
		System.out.println(title);
		System.out.println("-----------------------------------------------");
		for(Book b: books) {
			System.out.println(b);
		}
		System.out.println("-----------------------------------------------\n");
	}
}

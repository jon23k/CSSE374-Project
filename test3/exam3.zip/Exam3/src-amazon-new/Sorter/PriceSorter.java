package Sorter;

import com.amazon.model.Book;

public class PriceSorter implements ISorter{
	
	@Override
	public int compare(Book o1, Book o2) {
		if(o1.equals(o2))
			return 0;
		
		if(o1.getCost() < o2.getCost())
			return -1;
		
		// Greater or equal
		return 1;
	}

}

package Sorter;

import java.util.Comparator;

import com.amazon.model.Book;

public interface ISorter extends Comparator<Book>{

	public int compare(Book o1, Book o2);
	
}

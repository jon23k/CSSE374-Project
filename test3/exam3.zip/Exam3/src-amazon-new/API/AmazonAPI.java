package API;

import java.lang.reflect.Proxy;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import Adapter.EbayAmazonAdapter;
import People.AmazonDiamond;
import People.AmazonGold;
import People.PersonBean;
import Proxy.DiamondInvocationHandler;
import Proxy.GoldInvocationHandler;

import com.amazon.model.Book;
import com.amazon.model.Catalog;

public class AmazonAPI implements API {
	Catalog catalog;
	Catalog amazonBooks;
	Map<String, PersonBean> dataBase;

	public AmazonAPI() {
		catalog = new Catalog("Best Seller");
		amazonBooks = new Catalog("Amazon Books");
		DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);

		// NOTE: Assume making RESTful call to Amazon web services to retrieve
		// the following info

		//Book 1
		addingABook("Head First Design Patterns", "978-0-596-00712-6",
				new String[] { "Eric Freeman", "Elisabeth Freeman" },
				"O'Reilly", "October 1, 2004", 49.98f, format);
		//Book 2
		addingABook("Head First C++", "978-0-596-00712-7", new String[] {
				"Eric Fordeman", "Elisabeth Haggerman" }, "Addison Wesley",
				"October 1, 2005", 100f, format);
		//Book 3
		addingABook("Love and Peace", "978-0-596-00712-8", new String[] {
				"Bob Marley", "Pink Floyd" }, "Music Inc.", "September 12, 1982", 32f, format);
		// Book 4
		addingABook("Love and Prayer", "978-0-596-00712-8", new String[] {
				"Bob Marr", "Pink Panther" }, "Church Inc.", "November 18, 1801", 10.35f, format);
		
		// adding in the ebay books		
		EbayAmazonAdapter adapter = new EbayAmazonAdapter();
		Iterator<Book> iter = adapter.getBooks().iterator();
		while (iter.hasNext()) {
			catalog.add(iter.next());
		}
		// creating members 
		this.dataBase = Collections.synchronizedMap(new HashMap<String, PersonBean>());
		addInData();
	}
	
	public void addingABook(String title, String isbn, String[] authors, String publisher, String pubDate, float cost, DateFormat format){
		Date date = null;
		try{
			date = format.parse(pubDate);
		}catch (ParseException e) {
		}
		Book b = new Book(title,isbn,authors,publisher,date, cost);
		catalog.add(b);
		amazonBooks.add(b);
		
	}

	public PersonBean getGoldProxy(PersonBean gold) {

		return (PersonBean) Proxy.newProxyInstance(gold.getClass()
				.getClassLoader(), gold.getClass().getInterfaces(),
				new GoldInvocationHandler(gold));
	}

	public PersonBean getDiamondProxy(PersonBean diamond) {

		return (PersonBean) Proxy.newProxyInstance(diamond.getClass()
				.getClassLoader(), diamond.getClass().getInterfaces(),
				new DiamondInvocationHandler(diamond));
	}

	public Set<Book> getAmazonOnlyBooks() {
		return this.amazonBooks.getBooks();
	}
	public Set<Book> getAmazonOnlyBooksSorted(Comparator<Book> sorter) {
		return this.amazonBooks.getBooks(sorter);
	}

	public Set<Book> getBooks() {
		return catalog.getBooks();
	}
	/*
	 * (non-Javadoc)
	 * @see API.API#getBooksSorted(java.util.Comparator)
	 * take in a custom Comparator class to sort the data.
	 */
	public Set<Book> getBooksSorted(Comparator<Book> sorter) {
		return this.catalog.getBooks(sorter);
	}
	/*
	 * Getting the member from the database
	 */
	public PersonBean getPersonFromDatabase(String name) {
		return (PersonBean)dataBase.get(name);
	}
	/*
	 * adding the memebers into the database
	 */
	private void addInData(){
		PersonBean gold = new AmazonGold(this);
		PersonBean diamond = new AmazonDiamond(this);
		gold.setName("Joe");
		diamond.setName("Bob");
		this.dataBase.put(gold.getName(), gold);
		this.dataBase.put(diamond.getName(), diamond);
		
	}

}

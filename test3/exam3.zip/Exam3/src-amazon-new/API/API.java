package API;

import java.util.Comparator;
import java.util.Set;

import com.amazon.model.Book;

public interface API {

	public Set<Book> getBooks();
	public Set<Book> getBooksSorted(Comparator<Book> sorter);
}

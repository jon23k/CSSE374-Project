package Adapter;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

import API.API;

import com.amazon.model.Book;
import com.ebay.EBayBook;
import com.ebay.EbayAPI;

public class EbayAmazonAdapter implements API {

	EbayAPI api = new EbayAPI();

	@Override
	public Set<Book> getBooks() {
		Set<Book> set = new HashSet<Book>();
		for (int i = 0; i < this.api.getBooks().length; i++) {
			Book book = switchToBook(this.api.getBooks()[i]);
			set.add(book);
		}
		return set;
	}

	// not needed since all the books are in the catalog
	@Override
	public Set<Book> getBooksSorted(Comparator<Book> sorter) {
		return null;
	}

	public Book switchToBook(EBayBook book) {
		return new Book(book.getTitle(), book.getISBN(), book.getAuthors(),
				book.getPublisher(), book.getPublicationDate(), book.getPrice());
	}

}

package Client;

import java.util.Set;

import API.AmazonAPI;
import People.AmazonDiamond;
import People.AmazonGold;
import People.PersonBean;
import Sorter.PriceSorter;

import com.amazon.model.Book;

public class Client {
	public static void main(String[] args) {
		AmazonAPI api = new AmazonAPI();

		Set<Book> books = api.getBooks();
		print("Amazon Books and Ebay - All", books);

		books = api.getBooksSorted(new PriceSorter());
		print("Amazon and Ebay Books - Sorted by Price", books);

		PersonBean goldMember = api.getPersonFromDatabase("Joe");
		PersonBean gold = api.getGoldProxy((AmazonGold) goldMember);
		
		PersonBean diamondMember = api.getPersonFromDatabase("Bob");
		PersonBean diamond = api.getDiamondProxy((AmazonDiamond) diamondMember);

		books = diamond.getBooks();
		print("Diamond Member Books", books);

		books = gold.getBooks();
		print("Gold Member Books", books);

	}

	public static void print(String title, Set<Book> books) {
		System.out.println(title);
		System.out.println("-----------------------------------------------");
		for (Book b : books) {
			System.out.println(b);
		}
		System.out.println("-----------------------------------------------\n");
	}
}

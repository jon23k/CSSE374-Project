package People;

import java.util.Comparator;
import java.util.Set;

import API.AmazonAPI;

import com.amazon.model.Book;


public class AmazonGold implements PersonBean{
	String name;
	AmazonAPI api;
	
	public AmazonGold(AmazonAPI api) {
		this.api= api;
	}
	
	@Override
	public String getName() {
		return this.name;
	}
	
	@Override
	public String getMembership() {
		return "Gold";
	}
	
	@Override
	public void setName(String name) {
		this.name = name;
		
	}

	@Override
	public Set<Book> getBooks() {
		return this.api.getAmazonOnlyBooks();
	}

	@Override
	public Set<Book> getSortBooks(Comparator<Book> sorter) {
		return this.api.getAmazonOnlyBooksSorted(sorter);
	}

}

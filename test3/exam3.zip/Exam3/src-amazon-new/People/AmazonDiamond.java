package People;

import java.util.Comparator;
import java.util.Set;

import API.AmazonAPI;

import com.amazon.model.Book;

public class AmazonDiamond implements PersonBean {
	String name;
	AmazonAPI api;

	public AmazonDiamond(AmazonAPI amazonAPI) {
		this.api = amazonAPI;

	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public String getMembership() {
		return "Diamond";
	}

	@Override
	public void setName(String name) {
		this.name = name;

	}

	@Override
	public Set<Book> getBooks() {
		return this.api.getBooks();
	}

	@Override
	public Set<Book> getSortBooks(Comparator<Book> sorter) {
		return this.api.getAmazonOnlyBooksSorted(sorter);
	}

}

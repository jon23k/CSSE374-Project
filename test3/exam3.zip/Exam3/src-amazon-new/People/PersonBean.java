package People;

import java.util.Comparator;
import java.util.Set;

import com.amazon.model.Book;


public interface PersonBean {
	
	String getName();
	String getMembership();
	Set<Book> getBooks();
	Set<Book> getSortBooks(Comparator<Book> sorter);
	
	void setName(String name);
	

}

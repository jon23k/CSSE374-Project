package Test;

import static org.junit.Assert.assertEquals;

import java.util.Set;

import org.junit.Test;

import API.AmazonAPI;
import People.AmazonDiamond;
import People.AmazonGold;
import People.PersonBean;
import Sorter.PriceSorter;

import com.amazon.model.Book;

public class Feature3Test {
	@Test
	public void feature3Test(){
		AmazonAPI api = new AmazonAPI();

		Set<Book> books = api.getBooks();
	
		books = api.getBooksSorted(new PriceSorter());
	
		PersonBean goldMember = api.getPersonFromDatabase("Joe");
		PersonBean gold = api.getGoldProxy((AmazonGold) goldMember);
		
		PersonBean diamondMember = api.getPersonFromDatabase("Bob");
		PersonBean diamond = api.getDiamondProxy((AmazonDiamond) diamondMember);

		books = diamond.getBooks();
//		System.out.println(books);
			
		String expected = "[Book [title=Head First Design Patterns, isbn=978-0-596-00712-6, authors=[Eric Freeman, Elisabeth Freeman], publisher=O'Reilly, pubDate=Fri Oct 01 00:00:00 EDT 2004, cost=49.98], Book [title=The Design Patterns in Software Systems, isbn=978-0-596-00713-8, authors=[Chandan R. Rupakheti], publisher=Rose-Hulman, pubDate=Fri Sep 15 00:00:00 EDT 1989, cost=30.0], Book [title=Love and Peace, isbn=978-0-596-00712-8, authors=[Bob Marley, Pink Floyd], publisher=Music Inc., pubDate=Sun Sep 12 00:00:00 EDT 1982, cost=32.0], Book [title=Love and Prayer, isbn=978-0-596-00712-8, authors=[Bob Marr, Pink Panther], publisher=Church Inc., pubDate=Wed Nov 18 00:00:00 EST 1801, cost=10.35], Book [title=Head First C++, isbn=978-0-596-00712-7, authors=[Eric Fordeman, Elisabeth Haggerman], publisher=Addison Wesley, pubDate=Sat Oct 01 00:00:00 EDT 2005, cost=110.0], Book [title=Head First Design Patterns, isbn=978-0-596-00712-6, authors=[Eric Freeman, Elisabeth Freeman], publisher=O'Reilly, pubDate=Fri Oct 01 00:00:00 EDT 2004, cost=30.5], Book [title=Head First C++, isbn=978-0-596-00712-7, authors=[Eric Fordeman, Elisabeth Haggerman], publisher=Addison Wesley, pubDate=Sat Oct 01 00:00:00 EDT 2005, cost=100.0]]";
		
		assertEquals(expected, books.toString());
		
		books = gold.getBooks();
//		System.out.println(books);
		expected = "[Book [title=Head First Design Patterns, isbn=978-0-596-00712-6, authors=[Eric Freeman, Elisabeth Freeman], publisher=O'Reilly, pubDate=Fri Oct 01 00:00:00 EDT 2004, cost=49.98], Book [title=Love and Peace, isbn=978-0-596-00712-8, authors=[Bob Marley, Pink Floyd], publisher=Music Inc., pubDate=Sun Sep 12 00:00:00 EDT 1982, cost=32.0], Book [title=Love and Prayer, isbn=978-0-596-00712-8, authors=[Bob Marr, Pink Panther], publisher=Church Inc., pubDate=Wed Nov 18 00:00:00 EST 1801, cost=10.35], Book [title=Head First C++, isbn=978-0-596-00712-7, authors=[Eric Fordeman, Elisabeth Haggerman], publisher=Addison Wesley, pubDate=Sat Oct 01 00:00:00 EDT 2005, cost=100.0]]";
		
		assertEquals(expected, books.toString());
	}
}

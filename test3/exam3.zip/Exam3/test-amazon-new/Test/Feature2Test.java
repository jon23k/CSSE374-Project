package Test;

import static org.junit.Assert.assertTrue;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Set;

import org.junit.Test;

import API.AmazonAPI;

import com.amazon.model.Book;

public class Feature2Test {

	@Test
	public void feature2Test() {
		AmazonAPI api = new AmazonAPI();

		Set<Book> books = api.getBooks();
		DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);

		// Book 1
		String string = "October 1, 2005";
		Date date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {
		}
		// a book from ebay
		Book b = new Book("Head First C++", "978-0-596-00712-7", new String[] {
				"Eric Fordeman", "Elisabeth Haggerman" }, "Addison Wesley",
				date, 110f);
		
		assertTrue(books.contains(b));
		
		
		string = "October 1, 2004";
		date = null;
		try {
			date = format.parse(string);
		} catch (ParseException e) {
		}
		// another book from ebay
		b = new Book("Head First Design Patterns", 
				"978-0-596-00712-6",
				new String[]{"Eric Freeman", "Elisabeth Freeman"},
				"O'Reilly",
				date, 
				30.50f);
		
		
		assertTrue(books.contains(b));
	}
}
